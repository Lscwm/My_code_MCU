﻿#pragma once
#include <iostream>  
#include <opencv2/opencv.hpp>

//using namespace cv;

class QuickDemo {

public:
	int check(cv::Mat Video);





};

