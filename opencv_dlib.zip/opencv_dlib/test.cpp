﻿#include <iostream>  
#include <dlib/opencv.h>
#include <QuickDemo.h>
#include <opencv2/opencv.hpp>
#include <dlib/image_processing/frontal_face_detector.h>
#include <dlib/image_processing/render_face_detections.h>
#include <dlib/image_processing.h>
#include <dlib/gui_widgets.h>

using namespace dlib;
//using namespace cv;
using namespace std;

int main()
{
	system("color F1");
	cv::Mat image;
	QuickDemo spr;
	cv::VideoCapture cap(0);
	cv::namedWindow("outputdlib", cv::WINDOW_AUTOSIZE);						//创建窗口
	if (!cap.isOpened()) {
		cout << "Unable to connect to camera" << endl;        //检查摄像头是否打开
		return -1;
	}
	frontal_face_detector detector = get_frontal_face_detector();
	shape_predictor facepoint_model;
	deserialize("shape_predictor_68_face_landmarks.dat") >> facepoint_model;
	//调头用模型
	while (cv::waitKey(12) != 20)
	{
		cap >> image;
		spr.check(image);
		cv_image<bgr_pixel> dst(image);
		std::vector<rectangle> faces = detector(dst);             //获取脸部矩阵并赋值
		std::vector<full_object_detection> shapes;
		for (unsigned long i = 0; i < faces.size(); ++i)
			shapes.push_back(facepoint_model(dst, faces[i]));

		if (!shapes.empty()) {
			for (int i = 0; i < 68; i++)
			{
				circle(image, cvPoint(shapes[0].part(i).x(), shapes[0].part(i).y()), 3, cv::Scalar(0, 255, 0), -1);
				putText(image, to_string(i), cvPoint(shapes[0].part(i).x(), shapes[0].part(i).y()), cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar(255, 0, 0), 1, 4);
				//  shapes[0].part(i).x();//68个  
			}
		}

		imshow("outputdlib", image);

	}

}