﻿#include <iostream>  
#include <QuickDemo.h>
#include <opencv2/opencv.hpp>
#include <dlib/image_processing/frontal_face_detector.h>
#include <dlib/image_processing/render_face_detections.h>
#include <dlib/image_processing.h>
#include <dlib/gui_widgets.h>

//using namespace cv;
using namespace dlib;
using namespace std;


int QuickDemo::check(cv::Mat Video) {
	if (Video.empty())
	{
		cout << "No photos!!" << endl;

		return -1;
	}

}
//
//void QuickDemo::models_dlib() {
//
//	frontal_face_detector detector = get_frontal_face_detector();
//	shape_predictor pose_model;
//	deserialize("shape_predictor_68_face_landmarks.dat") >> pose_model;
//}